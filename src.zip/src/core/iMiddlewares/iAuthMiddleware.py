from abc import ABC, abstractmethod
from typing import Any
from fastapi import Request


class IAuthMiddleware(ABC):
    @abstractmethod
    async def is_logged_in(
        self, request: Request, refresh_token: str | None = None, throw_error: bool = True
    ) -> Any:
        pass

    @abstractmethod
    async def is_logged_out(
        self, request: Request, refresh_token: str | None = None
    ) -> None:
        pass

    @abstractmethod
    async def is_authorized(self, request: Request, *permissions) -> None:
        pass

    @abstractmethod
    async def is_ready(self, request: Request):
        pass

    @abstractmethod
    async def has_registered_subjects(self, request: Request):
        pass
