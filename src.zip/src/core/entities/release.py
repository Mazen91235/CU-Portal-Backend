from __future__ import annotations

from .base import (
    Base,
    Integer,
    String,
    TIMESTAMP,
    datetime,
    JSON,
    MutableDict,
    ForeignKey,
    Index,
    Mapped,
    Optional,
    TimezoneHandler,
    TypedDict,
    TYPE_CHECKING,
    mapped_column,
    relationship,
)

if TYPE_CHECKING:
    from .version import Version
    from .releaseItem import ReleaseItem


class Release(Base):
    # Tablename
    __tablename__ = "releases"

    # Columns
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    release_number: Mapped[str] = mapped_column(String(10), nullable=False)
    title: Mapped[str] = mapped_column(String(100), nullable=False)
    date: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False)
    details: Mapped[dict] = mapped_column(
        MutableDict.as_mutable(JSON), nullable=True, default=dict
    )  # extra details (e.g., description)

    # Timestamps
    created_at: Mapped[Optional[datetime]] = mapped_column(
        TIMESTAMP(timezone=True),
        default=lambda: TimezoneHandler.now("UTC"),
        nullable=True,
    )
    updated_at: Mapped[Optional[datetime]] = mapped_column(
        TIMESTAMP(timezone=True),
        default=lambda: TimezoneHandler.now("UTC"),
        onupdate=lambda: TimezoneHandler.now("UTC"),
        nullable=True,
    )

    # Versioning
    version: Mapped[int] = mapped_column(
        Integer, default=1, server_default="1", nullable=False
    )

    # Relationships
    release_version_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("versions.id"), nullable=False
    )
    release_version: Mapped["Version"] = relationship(
        "Version", back_populates="releases"
    )
    release_items: Mapped[set["ReleaseItem"]] = relationship(
        "ReleaseItem",
        back_populates="release",
        cascade="all, delete-orphan",
        collection_class=set,
    )

    # Arguments
    __table_args__ = (
        Index("idx_release_release_number", "release_number", unique=True),
    )
    __mapper_args__ = {
        "version_id_col": version,
    }
